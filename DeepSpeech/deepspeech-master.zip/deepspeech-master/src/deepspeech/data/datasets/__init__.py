from deepspeech.data.datasets.librispeech import LibriSpeech  # noqa: F401
