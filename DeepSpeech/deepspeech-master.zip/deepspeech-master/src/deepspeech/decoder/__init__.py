from deepspeech.decoder.beam import BeamCTCDecoder      # noqa: F401
from deepspeech.decoder.greedy import GreedyCTCDecoder  # noqa: F401
