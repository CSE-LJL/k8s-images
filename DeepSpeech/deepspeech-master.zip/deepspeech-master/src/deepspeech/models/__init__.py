# flake8: noqa
from deepspeech.models.deepspeech2 import DeepSpeech2
from deepspeech.models.deepspeech import DeepSpeech
from deepspeech.models.model import Model
